
#ifndef __OBJECT
#define __OBJECT



#include "Config.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>




typedef struct {
    double x;
    double y;
} Object;





Object *init_object(double x, double y);


#endif
